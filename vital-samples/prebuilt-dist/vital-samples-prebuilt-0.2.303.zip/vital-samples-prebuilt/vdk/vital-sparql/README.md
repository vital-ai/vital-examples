vital-sparql
=================

vital sparql endpoint
