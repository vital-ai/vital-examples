vital-ontology
==============

Repository of Vital AI ontologies
