vital-triplestore
=================

vital triplestore endpoint
