vitalutil
=========

vital util commands
